var express 			=require("express");
var router 				=express.Router();
var Campground    		=require("../models/campgrounds");
var Comment 	   		=require("../models/comments");
var middleware			=require("../middleware/index.js");


//======================================

router.get("/campgrounds/:id/comments/new",middleware.isLoggedIn,function(req,res){
	Campground.findById(req.params.id,function(err,campground){
		if(err)
			console.log(err);
		else
		{
			res.render("comments/new",{campground:campground,currentUser:req.user});
		}
	});
	
});

router.post("/campgrounds/:id/comments",middleware.isLoggedIn,function(req,res){
	//look up campground using ID
	Campground.findById(req.params.id,function(err,campground){
		if(err)
		{
			console.log(err);
			res.redirect("/campgrounds");
		}
		else
		{
			//create new comment
			Comment.create(req.body.comment,function(err,comment){
				if(err)
				{
					console.log(err);
					res.redirect("/campgrounds");
				}
				else
				{
					// add user name and id to the comment
					comment.author.id=req.user._id;
					comment.author.username=req.user.username;

					// saving the comment
					comment.save();

					//connect new comments to campgrounds
					campground.comments.push(comment);
					campground.save();
					res.redirect("/campgrounds/"+campground._id);
				}	
			});

		}
	});
});

// Edit a comment
router.get("/campgrounds/:campground_id/comments/:comment_id/edit",middleware.checkCommentOwnership,function(req,res){
	Campground.findById(req.params.campground_id,function(err,foundcamp){
		if(err)
		{
			res.redirect("/campgrounds");
			console.log(err);
		}
		else
		{
			Comment.findById(req.params.comment_id,function(err,foundcomment){
				if(err)
				{
					res.redirect("/campgrounds");
					console.log(err);
				}
				else
				{
					res.render("comments/edit",{campground:foundcamp, comment:foundcomment});
				}
			});
		}
	});
	
});


//comments update
router.put("/campgrounds/:campground_id/comments/:comment_id",middleware.checkCommentOwnership,function(req,res){
	Comment.findByIdAndUpdate(req.params.comment_id,req.body.comment,function(err,updatedcomment){
		if(err)
		{
			res.redirect("back");
			console.log(err);
		}
		else
		{
			res.redirect("/campgrounds/"+req.params.campground_id);
		}
	});
});



// Deleting a comment
router.delete("/campgrounds/:campground_id/comments/:comment_id",middleware.checkCommentOwnership,function(req,res){
	Comment.findByIdAndRemove(req.params.comment_id,function(err,foundComment){
		if(err)
		{
			res.redirect("back");
			console.log(err);
		}
		else
		{
			res.redirect("/campgrounds/"+req.params.campground_id);
		}
	});
});
module.exports=router;
// function isLoggedIn(req, res, next)
// {
// 	if(req.isAuthenticated())
// 	{
// 		return next();
// 	}
// 	else
// 	{
// 		res.redirect("/login");
// 	}

// }


// function checkCommentOwnership(req,res,next)
// {
// 	// is someone loggeed in
// 	if(req.isAuthenticated())
// 	{
// 		Comment.findById(req.params.comment_id,function(err,comment){
// 			if(err)
// 			{
// 				res.redirect("back");
// 			}
// 			else
// 			{
// 				// does the user own comment
// 				if(comment.author.id.equals(req.user._id))			// cant use campground.author.id==req.user._id as first  one is a javascript object and second one is string
// 					return next();
// 				else
// 					res.redirect("back");
// 			}
// 		});

// 	}
// 	else
// 	{
		
// 		res.redirect("back");
// 	}
// }

