var express 			=require("express");
var router 				=express.Router();
var Campground    		=require("../models/campgrounds");
var Comment 	   		=require("../models/comments");
var middleware			=require("../middleware/index.js");

// INDEX route
router.get("/campgrounds",function(req,res){
	//get all campgrounds from DB and then render it
	Campground.find({},function(err,allcampgrounds){
		if(err)
		{
			console.log("{something went wrong");
			console.log(err);
		}
		else
		{
			res.render("campgrounds/index",{campgrounds: allcampgrounds ,currentUser:req.user});
		}
	});

	// res.render("campgrounds",{campgrounds: campgrounds});
});


// NEW show form to create a new campground
router.get("/campgrounds/new",middleware.isLoggedIn,function(req,res){

	res.render("campgrounds/new");
});


// SHOW --- shows more information about one campground
router.get("/campgrounds/:id",function(req,res){

	//find the campground with provided id
	Campground.findById(req.params.id).populate("comments").exec(function(err,foundcamp){
		if(err)
		{
			console.log("Something went wrong");
			console.log(err);
		}
		else
		{
			//render more detail about the clicked item
			// console.log(foundcamp);
			res.render("campgrounds/show",{campground:foundcamp ,currentUser:req.user});
		}
	});


});

// CREATE route to add a new element to the database
router.post("/campgrounds",middleware.isLoggedIn,function(req,res){
	//get data from from and add to campground array
	//redirect back to campground
	var name=req.body.name;
	var image=req.body.image;
	var desc= req.body.desc;
	var author={
		id:req.user._id,
		username:req.user.username};
	var newCampGround={
		name:name,
		image:image,
		description:desc,
		author:author
	};
	// campgrounds.push(newCampGround);     // This is usesd to push the data in array

	// create  a new campground and save it to the db
	Campground.create(newCampGround,function(err,campground){
		if(err)
		{
			console.log("something went wrong");
			console.log(err);
		}
		else
		{
			res.redirect("/campgrounds");		// by default it is get request not a post request
		}
	});
});


//Edit campground
router.get("/campgrounds/:id/edit",middleware.checkCampgroundOwnership,function(req,res){
	Campground.findById(req.params.id,function(err,campground){
		res.render("campgrounds/edit",{campground:campground});
	});
});

//Update route
router.put("/campgrounds/:id",middleware.checkCampgroundOwnership,function(req,res){
	Campground.findByIdAndUpdate(req.params.id,req.body.campground,function(err,foundcamp){
		if(err)
		{
			console.log(err);
			res.redirect("/campgrounds");
		}
		else
		{
			res.redirect("/campgrounds/"+req.params.id);
		}

	});
});


//Delete campgroud
router.delete("/campgrounds/:id",middleware.checkCampgroundOwnership,function(req,res){
	Campground.findByIdAndRemove(req.params.id,function(err,campground){
		if(err)
		{
			res.redirect("/campgrounds");
		}
		else
		{
			res.redirect("/campgrounds");
		}
	});
});
module.exports=router;

//middleware

// function isLoggedIn(req, res, next)
// {
// 	if(req.isAuthenticated())
// 	{
// 		return next();
// 	}
// 	else
// 	{
// 		res.redirect("/login");
// 	}

// }


// function checkCampgroundOwnership(req,res,next)
// {
// 	// is someone loggeed in
// 	if(req.isAuthenticated())
// 	{
// 		Campground.findById(req.params.id,function(err,campground){
// 			if(err)
// 			{
// 				res.redirect("back");
// 			}
// 			else
// 			{
// 				// does the user own campground
// 				if(campground.author.id.equals(req.user._id))			// cant use campground.author.id==req.user._id as first  one is a javascript object and second one is string
// 					return next();
// 				else
// 					res.redirect("back");
// 			}
// 		});

// 	}
// 	else
// 	{
		
// 		res.redirect("back");
// 	}
// }


