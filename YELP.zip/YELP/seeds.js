var mongoose	  =require("mongoose");
var Campground    =require("./models/campgrounds");
var Comment  	  =require("./models/comments");
// var data=[
// 			{
// 				name:"Clouds rest",
// 				image:"https://pawnacamp.com/wp-content/uploads/2018/01/Pawna-lake-camping-camp-F-new2.jpg",
// 				description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
// 			},
// 			{
// 				name:"Snowy paradise",
// 				image:"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhISEhIVFhUVFRUVFRUVFxUVFRUVFRUWFhUVFRYYHSggGBolGxUVITEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OFxAQGi0fHx0tLS0tLS4tLS0tLS0tLS0tLy0tLSstLS0tLS0tLS0tLS0tLS0tKy0tLS0tLisuLS0tLf/AABEIAKgBKwMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAACAwABBAUGB//EADUQAAICAAQDBgUEAgIDAQAAAAABAhEDEiExBEFRBRNhcZGhFCKBsfAGMsHRYuFCchVS8SP/xAAZAQEBAQEBAQAAAAAAAAAAAAABAAIDBAX/xAAnEQACAgICAQIGAwAAAAAAAAAAAQIRAxIEITETUQUUQWFx4TKBwf/aAAwDAQACEQMRAD8A60YjFAOMRiias+YkKyguJoyA5SsqM7iU4mhxBcSsqM7QLiPcAHEbM0IlABo0NAuIphRmcQJRNLgLcTVlRnkhUoGmSAcRsyZXECUTTKIto0mRmnETKJrlEBxNJgZJRFuJqlEXKJpMjM0A4miUBTiasBLiLcTQ4guI2IiimhsoAuIjYrKVlGNEIReUlB0WQgpF0WWkBA0WXQWUrEGiqG5CnALES4gZB8kVQWJ9KjEPKHGAWU+dZ21FZQXEc4kcCstRDiC4D8pTiNhRncQXEe4gOJJg4meUQWjQ4gOJrYHEztASgaZQFuIpmWjM4i5RNUoipxNpmWjM4i5RNUoi3EUzNGVxFyia5REyRtMDNKIuUTVKIuUTVlRmlEXKJpcRcomkwozOILRolEW4jZCXEFxHZQco2QnIVkHNFUNkIykyDqJRWIrIXlG0SgsQFEJIKi0gs0gUi8oaReULIS4gd2aMoOUzYn0uKLoJRLcT5ux66AoFoblKcR2KhdA0NcQXEdgFuItxH0U4lsFGdxAlE0uIEoimDRmlEXKBqcRbRqzNGWUQJRNMoAOJqzLiZHEXKJslEVKA7GdTM4i5RNLiLcTSkZcTLKAtxNbiBKB02CjJKAqUTZKAuURUgoySiBKJqcBUoG7CjM4gtGhxKcRTLUzNFUPyFOA7FQii6G5CZCsqFUXlGqAWQLNUJUQlEaoF92FiKSCodh4TbpLVj8TgcSO8GvdeqMOaXTZpRk1aRgylZTU8MHIWyCj6MkSglEuj5Wx9HUCinEYVRbFqBlKyGzC4dL5sTSO+ulrnXPp6nTjwmE1biteWqdeOu55snMx43/pv0XR5/KVlO7Ls3Dezcet00BPsmNaT+bfVaf6NLmYmr2D0mcNwBcTc+FkstqszSV+I6XZM+sem7/o6vkY15YekzkSgKlhnVxuzprXLf/XX7GJwOkM0ZeHZh4zI4gSga3AXKJvcw8ZlyC5QNbiZ8bGjHRvV7Lm/oaUmYcBEoAd3ySNcFFxU3NQTv99rbyT8fQ6XD9mYaalKcZqOrirTtbN3yW/0X15ZOXjxrtnSPDyNrowf+LioayXetuoWlSSdprm9lfijlSwxvafFyxM8srWWVSk4/vyq46y5L5rb11W7B7KhPFlc8SKhl1bu020lKTapLfS9kaxTyRi5ZH+jWXBFtLGhEoipROpxPC5W1atK6tbLmns/Uxyiratab6rTz6HeGaMu0zzTwZIeUYpRAcDq43DYaSvF+ardK09qrW9n7Ax7PU9cPEi14qUdt1s17m1liZ9KXsclwAcDZxHDyg6f0adp+TQhxOqlas5tNMRkKyjsoOUUyF5SspowsBydJWXxOD3dXTfRW0tUvm2fPkTmkKi2Iw8JvZN+SuvM7vA8FwU4RU8bEhiL97y5oPXWq2rr9TlcbiRWVNqWjbg9IptWnFR/vnuD8SmlBxyxS/ZFZXot9Vez9jhNyyJOLa/B6I49HUkd3jeyeCjFyhxUp8qjFSd8vl00359BHZ3ZOFjW4zxElupwUJarR7tV+dL4+Hx8MJ5oyay7W4uTV7NVUk7a0Rr4/tPDlBYixEpx5wlG6dN0tJctvc4VlVJNv7s7rHjabaXR3sDs3DimknXOTerqn6aHQ4TtXDwssXFSS/bp8yjyqWzSVe2p4h/qv5KqTfV09L1vbVcvczcP+ocODb7l8tFNV6VSMT4ksie6s0sqhSiz3HbOBwuNJzjGUJf8mnFJrq41v46HF+G4Rb40r8MtfZnKxP1Zha//AJT2S3jrXXXxfU50/wBUq3pBeGrr62r9DePj5IrXukZcoSd9H0f4yN1eppUlat6Oqaun4eB5P49trM9tvz1B4XjZ4cVFSzLo6a9JbfQ8ksWRrp0fRWGC89nqnxEH+1qT6XWnVPmBLtOGHbkltpzp67tHj3xGJHM3iVe6Tb5balR46NauTbrlsa+TlLy20c/UguqUX9z1uDxEpuM38yTW+r6q1vFHVfa1Z97W+l16P6ng49sSjTjHWmrVptfnhRi4rtLElJuTavktNOXmc5fDpZZLbpLwMuRhhH3Pecf2pel7b9PzT3OZi9tzajDDxHd6JJtvyS1SPKQ7RSVVf13t7vxFT418vlS6P+T1Y+AorWvB558mD7T/AKPU4PbLhea3apPMpVbvTV1tshkf1VOD0pxVrdqXhyroeOfEtJ1J9Hen8meXG5nWZeV/lnR/Dsc+5Kzk+XJKkfROE/WzbUZYaeq0Xyyrwu02umlmyX6q4Ru2pKV08+H0fN60fL3jvqDi8S27bt9TnL4RhbtWvwzHzbR9U4j9TcEnF3Bp6tOHmt66nC7W/VmBWXDw1J9UnBL6vf0PBy4gW+Ja29eZ2xfDIY/q3+WD5No9Di/qDExGoxqFvStZer/pGDHnJSuTfi09736c7OTGbu03fXY2cNx+T/Jvdu/Rrmj1Sxa/xRY5Ql/Lr7/o0vtnFrLm000paPqvE6/Zn6gxY6zlq/omurp6s86uKg2moqLVNVtp4MRicQ03rv0OcuNDItdaO0OQ8Tty2PU9ofqGLfyv5710dP8APcT/AOXxLScqaTp6a2tpReldPI8r3utjsXjnLeumwrhxilFGPm1JuTVfg9jwXbLSyYiw2k9Iqo2uqqq1b9FZi4vi4Ybbw8ScdF8r+ZSet6xqL35rQ8r3xO+CPBjGTafkZc5OCWvj62eq4btiEk1J0+Typf8AX80Cwe2MHDjOPzpvXbn4a78/oeRliFZjouJH3PPLk7V12exj25g4kcrkkqpJxdxa6S2Wy2LUYPaV+X0/s8ZmCw8VxdptPqnQrjJeGcpZNvoephbbVVTrXbwdjVCK/dL0pfc8p8e1/wApeVsz4nFt72/M08L9zFnpuM7Uwo/sdyWnyt7Plm+nL2ONxPaE8R3J+miObLiV1AfFLqdI4oodmdPG7QxJVc2621enl0EPiG+bMD4lAvikaUEjTnJu2dGOOk9rXO/zcrExI7q/r/BzfiifEjqh2dUbpYqM+LxVaLczyxhbkPRkrElJ7sDKE5g5kBqz164+WxT45+Jy1isvvRWKJzeWfudH4sv4vwOb3hUsdLmPpoz6kjpPixc+LS3OXPi+gieP1JY0Nyfk6su0VyTEYnHN+Hkc94oPejqkVGuePe7b8wO9Rn7wF4pCjdHin1YXxTOd3oSxQFm54/iV3xi7wneijNG9YpO8Oe8YnflQm/vCd4Yu/LWKPQUbM5FNGPvCd4NIjZ3iK70yZys5aoKNnek75GLOR4haoja8YRicT1Mc8cRiYjYWkaSNc+MXJCJcS2JsimYs1QbxAe8AlIrMQ0Mzkzis5dhsh1YzOTvBTkUplsiod3pO8E5i1IbQUMcys4DKsio7eHxMHzLnxMFvJfc4ZKN2Z0R1nxseTBWKns/Q5aQSDYtUdIjMeHjNc0/uaITUtbFFRbYLZb8yUV0AJTQaRTQWKFl2W2iWFiW2U9gJz6APGZWVDSmhXesvvGVlQxBJsyS4hgPiWFlqb0Wn4nMlxMuot4je7Zb0Oh058VFc/QTLjehgIzLyM0oI1z458kB8VLwMxdmXJmtUaFxHVBPHMlksLZUalieJXeIz5iJlsyo0qSI76MzpkbCxoc2i0xCaLzjYUNkwaA7wnelaKg0XTAUrZHiUWxUN1BAWKTP4lZGhFmLD4p+BtwcRNaS81S8zUciYODRQcYl5fH2Lp+H2NWZpguKLw3XMjXg/pT9yKdJ/K/zxKyNXe2uXt9we8M6nHmkrLi48nQbFqOzi5a8wVfUpz6oti1LenMjb/GLeJ4aFKaK0VDM76ehSbYCxETTezNjRWJOis4UorwAcRshbKoYpVyT8ynK9/YmIuimMaXX1X9AqPimAi2RDu4fT7ASw30AQSmFk/NS1pyQELJQyUvApt9AsgCJEZEyEuyiWQiIiSZGymREIQhCQuyUUyIgNEbJYEJUgkwEiHE60OhiyT0bNMuMadOmlpp77mbh3rryTfotPekLYqTQNI3/GrowlxCZzS0bWRmXBHSk1p813uungXJrl/wDGYIYg7MdFNM5uNDpT639vzn6hN87vz3FRmufIkZrn7FYUNlLRfjCVWm9Ut1uZ5Vy/2XG3pu/zQrGjSsSKVbPXWmKi9Vzv25cgZxVJ0/q0RRVW9Omz9ddAsqHRjH/2rzVDYwWmvnWvoYc76vf6aBYc2tr10sio193Hqtr3v6aLcCWFGud89kvoBbt6OuQWGr0X9ApNFQLwHyV/cS8PXo+hpm2knYc5Kaj81Siq+ZPXW7T/AINJg1RkWJJc2EuI6ok1JC5SfNB5Ed3y6EeIuSfqmZ7RK6BRGh4i03I3rs635bdTMmFarZ/wFCOU0g5YkbpPTTXr5oxtkoiNCavdFQyvnX55iHDxKeH/AJIhNUstbrTyXpzAUVyrb7GemuZLfMrKjRlWr1+n+2KnXIHMSPl/BWVFpbvp49fAmviMbXjrvXIjaqs3TVrf8/kbEVlbKyeQdtbPw9+RcoS6Pr13AjI9ikwkrY7ClBJ2ndaVWr/yb5HGzoXh4XytrnpT9f6FRjvb2GQnpr9Bc09jKbAqUOgJGyJmhImGmCirEKCzMtYgMWRimFDozCTr+zMWpGti1N3eRfP21+vUdDBhJaP0ObmChKiavwwo6Pwb5OvzxYHw8tnJfVGePFPqaPjV0Rze6Ki/hnzkyRw5Ly8NPYFcYugceLRXNFQSX7ta0e9a+VvcBKOW27taNNaclf2JLiI9V6Cnj6bm1JvyDQ6OG6tP1teT6C5WrtA4eOo+Pr71uF30Xy38NHt/XKtzaphTGrF6xX1S+5eHgQnXJvx/vmK7vevlpW02mkr3T9PUU5OMq5rpQptPsKvwPxuBatxd1o1zMmV9DsYHEx7t6rNfzJ/8o8vT+TFHE/ya+l7nRpeUZi34ZismY1PDTT2b0rl7cwO4fJX7ffcxRuxMW3otSd49nsW0/wAr+AJJmR6Gxaa/b70RZbp2teetedf0IbLzdUFDQ15R8ctPVX5b+CSWnsYs/h66kc/AEwcTa4q9Vp4V0+ovEcVWi+/4vAyZiZhsVEbJLlWwOd9ELc2wc3gZs1RIMdGuaIQ5MWWq2em7+taBWuf5ZZABisXC5oU0Qgxdoky4MshDYlNELIRFUUQgoi7LzEIREzFqZRBsqJmCUyEIKLtEIQQKlaY2E7LIDRFtgFkMgW/P2/ojxWtiEEgY4xqjgzdaPXa618r3IQ0ifRWLPEjakq5ax/0KU3z1+/qiEF37mU+rDqD5e7/2R8On+37pkIN/Qn0KlgSW6bQt109yECSoYOxcqAciEMWdUisxVkIZsT//2Q==",
// 				description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
// 			},
// 			{
// 				name:"Pangyong Lake",
// 				image:"https://llic.b-cdn.net/pictures/travel/pangong-tso-lake-15.jpeg",
// 				description:"Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum"
// 			}
// ];
function seedDB(){
Campground.remove({},function(err){





	// if(err)
	// 	console.log(err);
	// else
	// 	{
	// 		console.log("removed campgrounds");
	// 		// add a few campgrounds
	// 		data.forEach(function(seed){
	// 			Campground.create(seed,function(err,campground){
	// 				if(err)
	// 					console.log(err);
	// 				else
	// 				{
	// 					// console.log(data);
	// 					// add a few comments
	// 					Comment.create(
	// 						{
	// 							text:"This place is great but has no Internet",
	// 							author:"Homer"								
	// 						},
	// 						function(err,comment)
	// 						{
	// 							if(err)
	// 								console.log(err);
	// 							else
	// 							{
	// 								campground.comments.push(comment);
	// 								campground.save();
	// 								console.log("created a new comment");
	// 							}
	// 						}							
	// 					);
	// 				}
	// 			});
	// 		});
	// 	}
	});
}

module.exports=seedDB;