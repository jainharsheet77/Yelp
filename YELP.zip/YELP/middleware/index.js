//a ll the middle wares go here

var middlewareObj={};
var Campground=require("../models/campgrounds.js");
var Comment=require("../models/comments.js");
middlewareObj.checkCampgroundOwnership= function(req,res,next)
{
	// is someone loggeed in
	if(req.isAuthenticated())
	{
		Campground.findById(req.params.id,function(err,campground){
			if(err)
			{
				res.redirect("back");
			}
			else
			{
				// does the user own campground
				if(campground.author.id.equals(req.user._id))			// cant use campground.author.id==req.user._id as first  one is a javascript object and second one is string
					return next();
				else
					res.redirect("back");
			}
		});

	}
	else
	{
		
		res.redirect("back");
	}
};


middlewareObj.checkCommentOwnership= function(req,res,next)
{
	// is someone loggeed in
	if(req.isAuthenticated())
	{
		Comment.findById(req.params.comment_id,function(err,comment){
			if(err)
			{
				res.redirect("back");
			}
			else
			{
				// does the user own comment
				if(comment.author.id.equals(req.user._id))			// cant use campground.author.id==req.user._id as first  one is a javascript object and second one is string
					return next();
				else
					res.redirect("back");
			}
		});

	}
	else
	{
		
		res.redirect("back");
	}
	
};

middlewareObj.isLoggedIn=function (req, res, next)
{
	if(req.isAuthenticated())
	{
		return next();
	}
	else
	{
		req.flash("error","Please Login First");
		res.redirect("/login");
	}

};


module.exports =middlewareObj;
