
//variable declartion
var express       =require("express"),
	request       =require("request"),
	bodyParser    =require("body-parser"), // for post route
	mongoose      =require("mongoose"),
	Campground    =require("./models/campgrounds"),
	seedDB		  =require("./seeds"),
	Comment 	  =require("./models/comments"),
	passport	  =require("passport"),
	LocalStrategy =require("passport-local"),
	User   		  =require("./models/user"),
	expressSession=require("express-session"),
	methodOverride=require("method-override"),
	flash		  =require("connect-flash");
var app=express();
	
// connecting database
mongoose.connect("mongodb://localhost:27017/yelp_camp",{useNewUrlParser:true,useUnifiedTopology: true});

// setting up app
app.set("view engine","ejs");
app.use(bodyParser.urlencoded({extended:true}));	// to be added every time we setup a post route 
app.use(express.static(__dirname+"public"));
app.use(methodOverride("_method"));
app.use(flash());

//seeding the database
// seedDB();	//to seed the database every time we start the server
//PASSPORT CONFIGURATION
app.use(expressSession(
	{
		secret:"ONCE AGAIN RUSTY IS A ",
		resave:false,
		saveUnitialized: false
	}
));

// setting up our own middleware to pass current user to all templates
app.use(function(req,res,next){
	res.locals.currentUser=req.user;
	res.locals.message= req.flash("error");
	next();
});



// connecting to routes
var commentRoutes		    =require("./routes/comments"),
	campgroundRoutes	    =require("./routes/campgrounds");
	indexRoutes 			=require("./routes/index");



app.use(passport.initialize());
app.use(passport.session());

passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());



//using routes
app.use(campgroundRoutes);
app.use(commentRoutes);
app.use(indexRoutes);


app.listen(3002,function(){
	console.log("YELP camp server has started");
});

